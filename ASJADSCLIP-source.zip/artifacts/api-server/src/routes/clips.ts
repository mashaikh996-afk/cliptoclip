import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import {
  CreateClipBody,
  CreateClipResponse,
  GetClipParams,
  GetClipResponse,
} from "@workspace/api-zod";
import { db, clipsTable } from "@workspace/db";

const router: IRouter = Router();

function getRetentionSettings(expiration: string) {
  const durations: Record<string, number> = {
    "10m": 10 * 60 * 1000,
    "1h": 60 * 60 * 1000,
    "24h": 24 * 60 * 60 * 1000,
    "7d": 7 * 24 * 60 * 60 * 1000,
  };

  if (expiration === "once") {
    return { expiresAt: null, burnAfterRead: true };
  }

  const duration = durations[expiration];
  return {
    expiresAt: duration ? new Date(Date.now() + duration) : null,
    burnAfterRead: false,
  };
}

function toApiClip(clip: typeof clipsTable.$inferSelect) {
  return {
    ...clip,
    id: String(clip.id),
  };
}

router.post("/clips", async (req, res): Promise<void> => {
  const parsed = CreateClipBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid clip body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const retention = getRetentionSettings(parsed.data.expiration);
  const [clip] = await db
    .insert(clipsTable)
    .values({
      name: parsed.data.name.trim(),
      code: parsed.data.code,
      language: parsed.data.language ?? null,
      expiresAt: retention.expiresAt,
      burnAfterRead: retention.burnAfterRead,
    })
    .onConflictDoUpdate({
      target: clipsTable.name,
      set: {
        code: parsed.data.code,
        language: parsed.data.language ?? null,
        expiresAt: retention.expiresAt,
        burnAfterRead: retention.burnAfterRead,
        updatedAt: new Date(),
      },
    })
    .returning();

  res.status(201).json(CreateClipResponse.parse(toApiClip(clip)));
});

router.get("/clips/:name", async (req, res): Promise<void> => {
  const parsed = GetClipParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [clip] = await db
    .select()
    .from(clipsTable)
    .where(eq(clipsTable.name, parsed.data.name));

  if (!clip) {
    res.status(404).json({ error: "No clip found with that name." });
    return;
  }

  if (clip.expiresAt && clip.expiresAt.getTime() <= Date.now()) {
    await db.delete(clipsTable).where(eq(clipsTable.id, clip.id));
    res.status(404).json({ error: "This clip has expired." });
    return;
  }

  const response = GetClipResponse.parse(toApiClip(clip));

  if (clip.burnAfterRead) {
    await db.delete(clipsTable).where(eq(clipsTable.id, clip.id));
  }

  res.json(response);
});

export default router;