# ASJADSCLIP

ASJADSCLIP lets people move code between devices by saving a snippet under a name and retrieving it from another screen without Bluetooth, accounts, or pairing.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/web/src/App.tsx` — the responsive save/retrieve clipboard experience
- `artifacts/web/src/index.css` — ASJADSCLIP visual theme, typography, and motion
- `lib/api-spec/openapi.yaml` — source of truth for clip API contracts
- `artifacts/api-server/src/routes/clips.ts` — clip save and retrieval handlers
- `lib/db/src/schema/clips.ts` — persistent clip storage schema

## Architecture decisions

- Clips are keyed by a user-provided name and saved with an upsert, so saving an existing name replaces its code.
- Each clip can stay until replaced, expire after a selected window, or be destroyed after its first successful retrieval.
- The browser uses generated React Query hooks from the OpenAPI contract rather than handwritten request types.
- The API exposes database IDs as strings to stay compatible with the workspace's current generated Zod schemas.

## Product

- Save a code snippet with a memorable name and optional language label.
- Choose never, 10 minutes, 1 hour, 24 hours, 7 days, or view once retention.
- Retrieve the named snippet from another device and copy the code to the local clipboard.
- Show clear empty, loading, success, not-found, retry, and copied states.

## User preferences

No additional preferences recorded.

## Gotchas

- Run API codegen after changing `lib/api-spec/openapi.yaml`.
- The API workflow must be running for save and retrieve actions to work in the preview.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
