import { useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Check, ChevronRight, Clipboard, Code2, Copy, Eraser, Loader2, LockKeyhole, MoveRight, RefreshCw, Send, Sparkles, Terminal } from 'lucide-react';
import { getGetClipQueryKey, useCreateClip, useGetClip, type Clip, type ClipExpiration } from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import './index.css';

const queryClient = new QueryClient();

function formatDate(value: string | Date) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'just now';
  return new Intl.DateTimeFormat('en', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(date);
}

function getErrorMessage(error: unknown, fallback: string) {
  if (typeof error === 'object' && error !== null && 'error' in error) {
    const message = (error as { error?: unknown }).error;
    if (typeof message === 'string' && message.trim()) return message;
  }
  if (error instanceof Error && error.message) return error.message;
  return fallback;
}

function describeRetention(clip: Pick<Clip, 'expiresAt' | 'burnAfterRead'>) {
  if (clip.burnAfterRead) return 'view once · disappears after retrieval';
  if (clip.expiresAt) return `expires ${formatDate(clip.expiresAt)}`;
  return 'stays until replaced';
}

function FieldLabel({ children, htmlFor, hint }: { children: string; htmlFor: string; hint?: string }) {
  return (
    <div className="mb-2 flex items-baseline justify-between gap-3">
      <label htmlFor={htmlFor} className="font-code text-[11px] font-medium uppercase tracking-[0.14em] text-foreground/70">
        {children}
      </label>
      {hint ? <span className="font-code text-[10px] text-muted-foreground">{hint}</span> : null}
    </div>
  );
}

function CodeSkeleton() {
  return (
    <div data-testid="loading-clip" className="space-y-3 p-5">
      {[82, 64, 91, 48, 74, 58].map((width, index) => (
        <div key={index} className="h-3 animate-pulse-soft rounded-sm bg-foreground/10" style={{ width: `${width}%` }} />
      ))}
    </div>
  );
}

function CodeWindow({ clip, onCopy, copied }: { clip: Clip; onCopy: () => void; copied: boolean }) {
  const lines = useMemo(() => clip.code.split('\n'), [clip.code]);

  return (
    <div data-testid={`card-clip-${clip.id}`} className="overflow-hidden rounded-[calc(var(--radius)+.15rem)] border border-foreground/15 bg-[#202a3a] shadow-[0_3px_0_hsl(222_31%_17%/.15),0_18px_32px_hsl(222_31%_17%/.14)]">
      <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex gap-1.5" aria-hidden="true">
            <span className="h-2 w-2 rounded-full bg-[#ef8269]" />
            <span className="h-2 w-2 rounded-full bg-[#f7cc5c]" />
            <span className="h-2 w-2 rounded-full bg-[#b9d56b]" />
          </div>
          <span data-testid={`text-clip-name-${clip.id}`} className="font-code text-[11px] text-white/75">{clip.name}</span>
        </div>
        <button
          type="button"
          data-testid={`button-copy-clip-${clip.id}`}
          onClick={onCopy}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 font-code text-[10px] uppercase tracking-[.12em] text-white/60 transition-colors hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f7cc5c]"
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <div className="max-h-[360px] overflow-auto px-0 py-4 font-code text-[12px] leading-6 text-[#dce6ef]">
        {lines.map((line, index) => (
          <div key={`${index}-${line}`} className="flex min-w-max pr-5">
            <span className="w-12 shrink-0 select-none pr-4 text-right text-white/25">{String(index + 1).padStart(2, '0')}</span>
            <code data-testid={`text-code-line-${clip.id}-${index}`} className="whitespace-pre">{line || ' '}</code>
          </div>
        ))}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 border-t border-white/10 px-4 py-2.5 text-[10px] text-white/40">
        <span className="font-code">{clip.language || 'plain text'}</span>
        <span className="font-code">{describeRetention(clip)}</span>
        <span className="font-code">{lines.length} {lines.length === 1 ? 'line' : 'lines'}</span>
      </div>
    </div>
  );
}

function Home() {
  const [saveName, setSaveName] = useState('');
  const [saveCode, setSaveCode] = useState('');
  const [saveLanguage, setSaveLanguage] = useState('');
  const [saveExpiration, setSaveExpiration] = useState<ClipExpiration>('never');
  const [retrieveInput, setRetrieveInput] = useState('');
  const [retrievedName, setRetrievedName] = useState('');
  const [savedClip, setSavedClip] = useState<Clip | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [saveError, setSaveError] = useState('');
  const [retrievalError, setRetrievalError] = useState('');

  const createClip = useCreateClip();
  const retrieval = useGetClip(retrievedName, {
    query: {
      enabled: Boolean(retrievedName),
      queryKey: getGetClipQueryKey(retrievedName),
    },
  });

  const retrievedClip = retrieval.data;

  const copyClip = async (clip: Clip) => {
    try {
      await navigator.clipboard.writeText(clip.code);
      setCopiedId(clip.id);
      window.setTimeout(() => setCopiedId((current) => (current === clip.id ? null : current)), 1800);
    } catch {
      setCopiedId(null);
    }
  };

  const submitSave = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = saveName.trim();
    const code = saveCode;
    if (!name || !code.trim()) return;
    setSaveError('');
    createClip.mutate(
      { data: { name, code, language: saveLanguage.trim() || null, expiration: saveExpiration } },
      {
        onSuccess: (clip) => {
          setSavedClip(clip);
          setRetrieveInput(clip.name);
        },
        onError: (error) => setSaveError(getErrorMessage(error, 'The clip could not be saved. Try again.')),
      },
    );
  };

  const submitRetrieve = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const name = retrieveInput.trim();
    if (!name) return;
    setRetrievalError('');
    if (name === retrievedName) {
      void retrieval.refetch().catch(() => undefined);
    } else {
      setRetrievedName(name);
    }
  };

  const clearRetrieve = () => {
    setRetrieveInput('');
    setRetrievedName('');
    setRetrievalError('');
  };

  const currentRetrievalError = retrieval.error ? getErrorMessage(retrieval.error, 'No clip was found with that name.') : retrievalError;

  return (
    <main className="noise min-h-[100dvh] overflow-hidden">
      <div className="mx-auto flex min-h-[100dvh] w-full max-w-[1440px] flex-col px-5 sm:px-8 lg:px-12">
        <header className="animate-rise flex items-center justify-between border-b border-foreground/10 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-foreground text-secondary shadow-[3px_3px_0_hsl(17_82%_56%)]">
              <Terminal size={19} strokeWidth={2.5} />
            </div>
            <div>
              <div data-testid="text-brand" className="font-display text-[15px] font-bold tracking-[-.03em]">ASJADSCLIP</div>
              <div className="font-code text-[9px] uppercase tracking-[.19em] text-muted-foreground">clipboard / 01</div>
            </div>
          </div>
          <div className="hidden items-center gap-2 sm:flex">
            <span className="h-2 w-2 animate-pulse-soft rounded-full bg-[#769e54]" />
            <span data-testid="status-service" className="font-code text-[10px] uppercase tracking-[.14em] text-muted-foreground">ready for handoff</span>
          </div>
        </header>

        <section className="grid flex-1 items-center gap-12 py-14 lg:grid-cols-[minmax(0,.92fr)_minmax(500px,1.08fr)] lg:gap-20 lg:py-20">
          <div className="animate-rise max-w-[620px]">
            <div className="mb-6 flex items-center gap-3">
              <span className="h-px w-10 bg-accent" />
              <span className="font-code text-[10px] font-medium uppercase tracking-[.2em] text-accent">A calmer way to move code</span>
            </div>
            <h1 className="font-display max-w-[680px] text-[clamp(3.4rem,8vw,7.6rem)] font-bold leading-[.88] tracking-[-.075em] text-foreground">
              Code in.<br />
              <span className="text-accent">Code out.</span>
            </h1>
            <p className="mt-8 max-w-[470px] text-[15px] leading-7 text-muted-foreground sm:text-[17px]">
              A small, named landing spot for the snippet you need on the other screen. No account. No pairing. Just a handoff that gets out of the way.
            </p>
            <div className="mt-10 flex flex-wrap gap-2.5">
              {[
                { icon: LockKeyhole, text: 'No accounts' },
                { icon: MoveRight, text: 'Any device' },
                { icon: Eraser, text: 'Auto-replace' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-2 rounded-full border border-foreground/10 bg-card/60 px-3 py-2 font-code text-[10px] uppercase tracking-[.08em] text-muted-foreground">
                  <Icon size={13} className="text-accent" />
                  {text}
                </div>
              ))}
            </div>
            <div className="mt-14 hidden items-center gap-3 lg:flex">
              <div className="flex -space-x-1">
                {['you', 'them', 'now'].map((label, index) => (
                  <div key={label} className={`flex h-7 w-7 items-center justify-center rounded-full border-2 border-background font-code text-[8px] font-medium ${index === 1 ? 'bg-secondary' : index === 2 ? 'bg-accent text-accent-foreground' : 'bg-foreground text-primary-foreground'}`}>
                    {index + 1}
                  </div>
                ))}
              </div>
              <span className="font-code text-[10px] uppercase tracking-[.1em] text-muted-foreground">your desk → another desk → done</span>
            </div>
          </div>

          <div className="relative animate-rise-delay">
            <div className="paper-grid absolute -inset-5 -z-10 rounded-[2rem] opacity-50" />
            <div className="grid gap-5 md:grid-cols-[1fr_44px_1fr] md:items-stretch">
              <section className="rounded-2xl border border-foreground/15 bg-card p-5 shadow-[var(--shadow-md)] sm:p-6">
                <div className="mb-6 flex items-start justify-between">
                  <div>
                    <div className="mb-2 flex items-center gap-2">
                      <span className="flex h-6 w-6 items-center justify-center rounded-md bg-secondary text-foreground"><Send size={13} /></span>
                      <span className="font-code text-[10px] uppercase tracking-[.18em] text-muted-foreground">01 / send</span>
                    </div>
                    <h2 className="font-display text-2xl font-bold tracking-[-.04em]">Leave a clip</h2>
                  </div>
                  <span className="font-code text-[10px] text-muted-foreground">POST</span>
                </div>
                <form onSubmit={submitSave} className="space-y-5">
                  <div>
                    <FieldLabel htmlFor="save-name" hint="required">clip name</FieldLabel>
                    <input id="save-name" data-testid="input-save-name" value={saveName} onChange={(event) => setSaveName(event.target.value)} maxLength={80} placeholder="morning-query" className="h-11 w-full rounded-lg border border-input bg-background/70 px-3 font-code text-[13px] text-foreground outline-none transition-[border,box-shadow] placeholder:text-muted-foreground/60 focus:border-accent focus:ring-2 focus:ring-accent/20" />
                  </div>
                  <div>
                    <FieldLabel htmlFor="save-language" hint="optional">language</FieldLabel>
                    <input id="save-language" data-testid="input-save-language" value={saveLanguage} onChange={(event) => setSaveLanguage(event.target.value)} maxLength={40} placeholder="typescript" className="h-11 w-full rounded-lg border border-input bg-background/70 px-3 font-code text-[13px] text-foreground outline-none transition-[border,box-shadow] placeholder:text-muted-foreground/60 focus:border-accent focus:ring-2 focus:ring-accent/20" />
                  </div>
                  <div>
                    <FieldLabel htmlFor="save-expiration" hint="privacy">availability</FieldLabel>
                    <select
                      id="save-expiration"
                      data-testid="select-save-expiration"
                      value={saveExpiration}
                      onChange={(event) => setSaveExpiration(event.target.value as ClipExpiration)}
                      className="h-11 w-full appearance-none rounded-lg border border-input bg-background/70 px-3 font-code text-[13px] text-foreground outline-none transition-[border,box-shadow] focus:border-accent focus:ring-2 focus:ring-accent/20"
                    >
                      <option value="never">Keep until replaced</option>
                      <option value="10m">Delete after 10 minutes</option>
                      <option value="1h">Delete after 1 hour</option>
                      <option value="24h">Delete after 24 hours</option>
                      <option value="7d">Delete after 7 days</option>
                      <option value="once">View once, then destroy</option>
                    </select>
                    <p className="mt-2 font-code text-[10px] leading-4 text-muted-foreground">
                      {saveExpiration === 'once' ? 'The first successful retrieval permanently destroys this clip.' : 'The clip is automatically removed when this window ends.'}
                    </p>
                  </div>
                  <div>
                    <FieldLabel htmlFor="save-code" hint={`${saveCode.length.toLocaleString()} chars`}>code</FieldLabel>
                    <textarea id="save-code" data-testid="input-save-code" value={saveCode} onChange={(event) => setSaveCode(event.target.value)} maxLength={100000} placeholder={'const handoff = true;\\n\\n// paste something useful here'} className="min-h-[178px] w-full resize-y rounded-lg border border-input bg-[#202a3a] px-3 py-3 font-code text-[12px] leading-6 text-[#dce6ef] outline-none transition-[border,box-shadow] placeholder:text-white/25 focus:border-secondary focus:ring-2 focus:ring-secondary/20" />
                  </div>
                  {saveError ? <div data-testid="status-save-error" role="alert" className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2.5 font-code text-[11px] leading-5 text-destructive">{saveError}</div> : null}
                  <button type="submit" data-testid="button-save-clip" disabled={createClip.isPending || !saveName.trim() || !saveCode.trim()} className="group flex h-12 w-full items-center justify-between rounded-lg bg-accent px-4 font-display text-sm font-bold text-accent-foreground shadow-[3px_3px_0_hsl(222_31%_17%/.18)] transition-[transform,box-shadow,background-color] hover:bg-[#e96b45] active:translate-x-[2px] active:translate-y-[2px] active:shadow-none disabled:cursor-not-allowed disabled:opacity-50">
                    <span>{createClip.isPending ? 'Leaving clip…' : 'Leave clip'}</span>
                    {createClip.isPending ? <Loader2 size={16} className="animate-spin" /> : <ChevronRight size={17} className="transition-transform group-hover:translate-x-1" />}
                  </button>
                </form>
                {savedClip ? (
                  <div data-testid="status-save-success" className="mt-4 flex items-start gap-2.5 rounded-lg border border-[#769e54]/30 bg-[#769e54]/10 px-3 py-3 text-[#517437]">
                    <Check size={15} className="mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <div className="font-code text-[11px] font-medium">Clip is waiting at <span className="font-bold">{savedClip.name}</span></div>
                      <div className="mt-1 text-[11px] text-[#517437]/75">Use that name on the other device · {describeRetention(savedClip)}.</div>
                    </div>
                  </div>
                ) : null}
              </section>

              <div className="hidden items-center justify-center md:flex">
                <div className="flex h-full flex-col items-center justify-center gap-3">
                  <div className="h-16 w-px bg-foreground/10" />
                  <div className="flex h-9 w-9 items-center justify-center rounded-full border border-foreground/15 bg-background text-accent"><MoveRight size={16} /></div>
                  <div className="h-16 w-px bg-foreground/10" />
                </div>
              </div>

              <section className="rounded-2xl border border-foreground/15 bg-foreground p-5 text-primary-foreground shadow-[var(--shadow-md)] sm:p-6">
                <div className="mb-6 flex items-start justify-between">
                  <div>
                    <div className="mb-2 flex items-center gap-2">
                      <span className="flex h-6 w-6 items-center justify-center rounded-md bg-secondary text-foreground"><Clipboard size={13} /></span>
                      <span className="font-code text-[10px] uppercase tracking-[.18em] text-white/45">02 / receive</span>
                    </div>
                    <h2 className="font-display text-2xl font-bold tracking-[-.04em]">Find your clip</h2>
                  </div>
                  <span className="font-code text-[10px] text-white/35">GET</span>
                </div>
                <form onSubmit={submitRetrieve} className="flex gap-2">
                  <input id="retrieve-name" data-testid="input-retrieve-name" value={retrieveInput} onChange={(event) => setRetrieveInput(event.target.value)} placeholder="type the clip name" className="h-11 min-w-0 flex-1 rounded-lg border border-white/15 bg-white/[.07] px-3 font-code text-[12px] text-white outline-none transition-[border,box-shadow] placeholder:text-white/35 focus:border-secondary focus:ring-2 focus:ring-secondary/20" />
                  <button type="submit" data-testid="button-retrieve-clip" disabled={!retrieveInput.trim() || retrieval.isFetching} className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-secondary text-foreground transition-[transform,background-color] hover:bg-[#ffe37d] active:scale-95 disabled:cursor-not-allowed disabled:opacity-45" aria-label="Retrieve clip">
                    {retrieval.isFetching ? <Loader2 size={16} className="animate-spin" /> : <ChevronRight size={18} />}
                  </button>
                </form>
                <div className="mt-5 min-h-[267px] overflow-hidden rounded-xl border border-white/10 bg-[#182131]">
                  {!retrievedName ? (
                    <div data-testid="empty-retrieve" className="flex h-[267px] flex-col items-center justify-center px-6 text-center">
                      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full border border-white/10 text-white/35"><Code2 size={19} /></div>
                      <div className="font-display text-sm font-semibold text-white/75">Nothing on the line yet</div>
                      <p className="mt-2 max-w-[190px] font-code text-[10px] leading-5 text-white/35">Enter a clip name to pull it across.</p>
                    </div>
                  ) : retrieval.isLoading || retrieval.isFetching ? (
                    <CodeSkeleton />
                  ) : currentRetrievalError ? (
                    <div data-testid="status-retrieve-error" role="alert" className="flex h-[267px] flex-col items-center justify-center px-6 text-center">
                      <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-full border border-[#ef8269]/30 text-[#ef8269]"><RefreshCw size={18} /></div>
                      <div className="font-display text-sm font-semibold text-white/80">That clip stayed behind</div>
                      <p className="mt-2 max-w-[230px] font-code text-[10px] leading-5 text-white/40">{currentRetrievalError}</p>
                      <button type="button" data-testid="button-retry-retrieve" onClick={() => void retrieval.refetch()} className="mt-4 inline-flex items-center gap-2 rounded-md border border-white/15 px-3 py-2 font-code text-[10px] uppercase tracking-[.1em] text-white/65 transition-colors hover:border-secondary hover:text-secondary">
                        <RefreshCw size={12} /> Try again
                      </button>
                    </div>
                  ) : retrievedClip ? (
                    <CodeWindow clip={retrievedClip} copied={copiedId === retrievedClip.id} onCopy={() => void copyClip(retrievedClip)} />
                  ) : (
                    <div data-testid="empty-clip-result" className="flex h-[267px] items-center justify-center font-code text-[10px] text-white/40">No code in this clip.</div>
                  )}
                </div>
                {retrievedClip ? (
                  <div className="mt-3 flex items-center justify-between gap-3">
                    <span data-testid="text-retrieved-time" className="font-code text-[10px] text-white/35">updated {formatDate(retrievedClip.updatedAt)}</span>
                    <button type="button" data-testid="button-clear-retrieve" onClick={clearRetrieve} className="inline-flex items-center gap-1.5 font-code text-[10px] uppercase tracking-[.1em] text-white/45 transition-colors hover:text-secondary"><Eraser size={12} /> Clear</button>
                  </div>
                ) : retrievedName ? (
                  <button type="button" data-testid="button-clear-retrieve-error" onClick={clearRetrieve} className="mt-3 inline-flex items-center gap-1.5 font-code text-[10px] uppercase tracking-[.1em] text-white/45 transition-colors hover:text-secondary"><Eraser size={12} /> Clear search</button>
                ) : null}
              </section>
            </div>
          </div>
        </section>

        <footer className="animate-rise-delay-2 flex flex-col gap-4 border-t border-foreground/10 py-5 text-[10px] text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-2 font-code uppercase tracking-[.12em]"><Sparkles size={12} className="text-accent" /> Built for the in-between moments</div>
          <div className="font-code uppercase tracking-[.12em]">temporary by design · private by default</div>
        </footer>
      </div>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;